import http from './fetch'
import axios from 'axios'

export const getRequestData = () => {
    let data = {
        head: {
            version: '1.0',
            uid: $cookies.get('id'),
            token: $cookies.get('f'),
            timestamp: Date.parse(new Date())
        },
        body: {}
    };
    return data;
}

axios.interceptors.response.use(function (res) {
    // let redirectUrl = "http://114.55.11.139:1101/#/";
    let redirectUrl = "http://47.244.139.179/#/";

    if (res.data.errCode == 10100) {
        $cookies.remove('id'),
            $cookies.remove('f'),
            $cookies.remove('account'),
            alert("token已失效，即将跳转至登录页~");
        window.location.href = redirectUrl;
    } else if (res.data.errCode == 10001) {
        $cookies.remove('id'),
            $cookies.remove('f'),
            $cookies.remove('account'),
            alert("服务错误，即将跳转至登录页~");
        window.location.href = redirectUrl;
    }
    return res;
}, function (err) {
    return Promise.reject(err);
})

// 管理员管理
// -登录
export const adminLogin = (data) => {
    return http.postFetch("admin/adminLogin", data);
}
// -退出
export const logout = (data) => {
    return http.postFetch("admin/logout", data);
}
// -管理员列表
export const listAdmin = (data) => {
    return http.postFetch("admin/listAdmin", data);
}
// -添加管理员
export const createAdmin = (data) => {
    return http.postFetch("admin/addAdmin", data);
}
// -删除管理员
export const delAdmin = (data) => {
    return http.postFetch("admin/delAdmin", data);
}
// -日志记录列表
export const logList = (data) => {
    return http.postFetch("logRecord/getLists", data);
}
// -添加或编辑备注
export const saveOrUpadteRemark = (data) => {
    return http.postFetch("logRecord/saveOrUpadteRemark", data);
}
// -手机号查询
export const getAdmin = (data) => {
    return http.postFetch("admin/getAdmin", data);
}

// 用户管理
// -用户列表
export const accountList = (data) => {
    return http.postFetch("account/accountList", data);
}
// -修改用户权限
export const updatePower = (data) => {
    return http.postFetch("account/updatePower", data);
}
// -修改用户手机信息
export const updatePhone = (data) => {
    return http.postFetch("account/updatePhone", data);
}
// -清除认证
export const clearAuth = (data) => {
    return http.postFetch("account/clearAuth", data);
}
// -查询用户推广列表
export const inviteList = (data) => {
    return http.postFetch("invite/list", data);
}
// -查询用户奖励列表
export const inviteBonousList = (data) => {
    return http.postFetch("invite/bounsList", data);
}
// -查询推广设置
export const bounsDetail = (data) => {
    return http.postFetch("bouns/detail", data);
}
// -修改推广奖励基数
export const updateBounsNumber = (data) => {
    return http.postFetch("bouns/updateBounsNumber", data);
}
// -添加奖励比率
export const bounsAdd = (data) => {
    return http.postFetch("bouns/add", data);
}
// -删除奖励比率
export const bounsDelete = (data) => {
    return http.postFetch("bouns/delete", data);
}
// -修改奖励比率
export const bounsUpdate = (data) => {
    return http.postFetch("bouns/update", data);
}
// -修改推广奖励文本
export const bounsUpdateExplain = (data) => {
    return http.postFetch("bouns/updateExplain", data);
}
// -查询邀请奖励出币地址
export const bounsBalance = (data) => {
    return http.postFetch("bouns/bounsBalance", data);
}

// 资产管理
// -充币记录
export const rechargeList = (data) => {
    return http.postFetch("asset/rechargeList", data);
}
// -查询列表
export const assetList = (data) => {
    return http.postFetch("asset/list", data);
}
// -待提币列表
export const withdrawList = (data) => {
    return http.postFetch("asset/withdrawList", data);
}
// -提币历史列表
export const withdrawHistoryList = (data) => {
    return http.postFetch("asset/withdrawHistoryList", data);
}
// -提币审核通过
export const withdrawAuditing = (data) => {
    return http.postFetch("asset/withdrawAuditing", data);
}
// -提币撤回
export const withdrawCancel = (data) => {
    return http.postFetch("asset/withdrawCancel", data);
}

// 宣言管理
// -宣言列表
export const declareList = (data) => {
    return http.postFetch("declare/list", data);
}
// -删除宣言
export const deleteDeclare = (data) => {
    return http.postFetch("declare/delete", data);
}
// -宣言详情
export const declareDetail = (data) => {
    return http.postFetch("declare/detail", data);
}

// 空投管理
// -空投地址列表
export const adAddress = (data) => {
    return http.postFetch("airDrop/addressPage", data);
}
// -空投记录列表
export const adRecord = (data) => {
    return http.postFetch("airDrop/recordPage", data);
}
// -空投
export const dropcoin = (data) => {
    return http.postFetch("airDrop/dropcoin", data);
}
// -查询空投出币地址
export const airdropAddress = (data) => {
    return http.postFetch("airDrop/airdropAddress", data);
}
// -查询空投出币地址余额
export const addressBalance = (data) => {
    return http.postFetch("airDrop/addressBalance", data);
}

// 评论管理
// -评论列表
export const commentList = (data) => {
    return http.postFetch("comment/list", data);
}
// -删除评论
export const commentDelete = (data) => {
    return http.postFetch("comment/delect", data);
}
// -禁止评论
export const commentForbid = (data) => {
    return http.postFetch("comment/forbid", data);
}

// 黑名单
// -添加、编辑黑名单
export const addBlacklist = (data) => {
    return http.postFetch("account/addBlacklist", data);
}
// -解除黑名单
export const breakBlacklist = (data) => {
    return http.postFetch("account/breakBlacklist", data);
}
// -黑名单列表
export const blacklist = (data) => {
    return http.postFetch("account/blacklist", data);
}

// 消息管理模块
// -修改定时发送消息
export const msgPartUpdate = (data) => {
    return http.postFetch("message/partUpdate", data);
}
// -删除定时发送消息
export const msgPartDelete = (data) => {
    return http.postFetch("message/partDelete", data);
}
// -发送全体消息（包括定时）
export const msgAll = (data) => {
    return http.postFetch("message/all", data);
}
// -发送指定消息（包括定时）
export const msgPart = (data) => {
    return http.postFetch("message/part", data);
}
// -查询历史消息
export const msgHistory = (data) => {
    return http.postFetch("message/history", data);
}
// -查询定时发送列表
export const msgTimeHistory = (data) => {
    return http.postFetch("message/timeHistory", data);
}

// 广告管理
// -上传图片
export const advUpload = (data) => {
    return http.postFetch("adv/upload", data);
}
// -查询广告
export const advDetail = (data) => {
    return http.postFetch("declare/advdetail", data);
}
// -新增广告
export const advAdd = (data) => {
    return http.postFetch("declare/addAdv", data);
}
// -修改广告
export const advUpdate = (data) => {
    return http.postFetch("declare/editadv", data);
}