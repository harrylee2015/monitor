<template>
  <header class="header">
    <div class="title">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item>{{$store.state.headerName}}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div
      class="refresh"
      @click="refreshHandle"
    >
      <span class="fa fa-refresh"></span>
      <span>刷新</span>
    </div>
  </header>
</template>
<script>
export default {
  props: ["refresh"],
  methods: {
    refreshHandle() {
      this.refresh();
    }
  }
};
</script>
<style>
header.header {
  background-color: #e4e4e4;
  padding: 8.8px 80px;
  padding-right: 95px;
  display: flex;
  justify-content: space-between;
  color: gray;
  height: 56px;
}
header.header > div.title {
  margin-top: 12px;
}
header.header > div.refresh {
  padding: 10px 11px;
  border: 1px solid lightgray;
  background-color: white;
}
header.header > div.refresh:hover {
  cursor: pointer;
  background-color: rgb(236, 238, 240);
}
header.header > div.refresh > span:nth-of-type(2) {
  position: relative;
  top: -2px;
}
header.header > div.refresh > span.fa-refresh {
  margin-right: 6px;
  font-size: 16px;
}
</style>

