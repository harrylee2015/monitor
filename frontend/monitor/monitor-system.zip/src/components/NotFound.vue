<template>
    <div class="notFound">
        <p>你迷路了</p>
    </div>
</template>

<script>
export default {

}
</script>

<style>
div.notFound{
    display: flex;
    justify-content: center;
    align-items: center;
}
.notFound>p{
    color: red;
    font-weight: 900;
    font-size: 70px!important;
}
</style>
