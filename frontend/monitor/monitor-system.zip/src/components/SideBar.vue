<template>
  <div class="sidebar_container">
    <el-menu
      class="el-menu-vertical-demo"
      background-color="#222D32"
      text-color="#b8c7ce"
      active-text-color="#fff"
      :unique-opened="true"
      :default-active="$store.state.defaultActive"
    >

      <el-submenu index="1">
        <template slot="title">
          <i class="fa fa-user title-icon"></i>
          <span>用户管理</span>
        </template>
        <el-menu-item
          index="1-1"
          @click="toLink('user-info')"
        ><i class="fa fa-circle-o item-icon"></i>用户信息</el-menu-item>
        <el-menu-item
          index="1-2"
          @click="toLink('promotion-reward')"
        ><i class="fa fa-circle-o item-icon"></i>推广奖励</el-menu-item>
      </el-submenu>
      <el-menu-item
        index="2-1"
        @click="toLink('declaration-mgr')"
      ><i class="fa fa-twitter item-icon"></i>宣言管理</el-menu-item>
      <el-menu-item
        index="3"
        @click="toLink('msg-mgr')"
      ><i class="fa fa-comments-o item-icon"></i>消息管理</el-menu-item>
      <el-menu-item
        index="4"
        @click="toLink('blacklist-mgr')"
      ><i class="fa fa-user-times item-icon"></i>黑名单</el-menu-item>
      <el-submenu index="5">
        <template slot="title">
          <i class="fa fa-jpy title-icon"></i>
          <span>资产管理</span>
        </template>
        <el-menu-item
          index="5-1"
          @click="toLink('asset-mgr')"
        ><i class="fa fa-circle-o item-icon"></i>资产管理</el-menu-item>
        <el-menu-item
          index="5-2"
          @click="toLink('coin-in')"
        ><i class="fa fa-circle-o item-icon"></i>充币记录</el-menu-item>
        <el-menu-item
          index="5-3"
          @click="toLink('coin-out-review')"
        ><i class="fa fa-circle-o item-icon"></i>提币审核</el-menu-item>
        <el-menu-item
          index="5-4"
          @click="toLink('coin-out')"
        ><i class="fa fa-circle-o item-icon"></i>提币历史记录</el-menu-item>
      </el-submenu>
      <el-menu-item
        index="7"
        @click="toLink('ad-mgr')"
      ><i class="fa fa-bullhorn item-icon"></i>广告管理</el-menu-item>
      <el-submenu index="6">
        <template slot="title">
          <i class="fa fa-sliders title-icon"></i>
          <span>系统管理</span>
        </template>
        <el-menu-item
          index="6-1"
          @click="toLink('operation-log')"
        ><i class="fa fa-circle-o item-icon"></i>操作日志</el-menu-item>
        <el-menu-item
          index="6-2"
          @click="toLink('admin-mgr')"
        ><i class="fa fa-circle-o item-icon"></i>后台管理员</el-menu-item>
      </el-submenu>
    </el-menu>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {
    toLink(url) {
      this.$router.push({ name: url });
    }
  },
  mounted() {}
};
</script>

<style>
.sidebar_container {
  width: 100%;
}
.sidebar_container .el-menu {
  border-right: solid 0px #e6e6e6 !important;
}
.sidebar_container .el-submenu .title-icon {
  font-size: 18px;
  width: 18px;
  margin-right: 10px;
  text-align: center;
}
.sidebar_container .el-menu-item .item-icon {
  font-size: 18px;
  width: 18px;
  margin-right: 15px;
  text-align: center;
}
.sidebar_container .el-submenu .item-icon {
  font-size: 10px;
  width: 10px;
  margin-right: 10px;
  text-align: center;
}
.sidebar_container .el-submenu > ul > li {
  background: #2c3b41 !important;
}
</style>
