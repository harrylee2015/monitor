<template>
  <div class="coinIn_container">
    <section class="search_container">
      <ul style="display: flex;justify-content: start;">
        <li>
          <el-input
            v-model="searchContent.searchKey"
            placeholder="UID/姓名"
          ></el-input>
          状态：<el-select v-model="searchContent.status">
            <el-option label="全部" value="" />
            <el-option label="处理中" value="1" />
            <el-option label="区块链异常" value="2" />
            <el-option label="已完成" value="3" />
          </el-select>
        </li>
        <li>
          日期：<el-date-picker
            v-model="createTime"
            type="daterange"
            range-separator="-"
            unlink-panels
            start-placeholder="起始日期"
            end-placeholder="截至日期"
            @change="handleDateChange"
          >
          </el-date-picker>
        </li>
        <li>
          <el-button-group>
            <el-button
              type="primary"
              @click="handleSearch"
            ><i class="el-icon-search"></i></el-button>
            <el-button
              type="primary"
              @click="resetSearchContent"
            ><i class="el-icon-refresh"></i></el-button>
          </el-button-group>
        </li>
      </ul>
    </section>
    <section class="main_container">
      <el-row>
        <el-button
          size="small"
          type="primary"
          @click="addCoinInVisibleDialog = true"
        >手工入币</el-button>
      </el-row>
      <el-row>
        <el-table
          :data="ciData"
          ref="ciTable"
        >
          <el-table-column
            prop="gmId"
            label="UID"
            width="100"
          >

          </el-table-column>
          <el-table-column
            label="姓名"
            align="center"
          >
            <template slot-scope="scope">
              <p v-if="scope.row.userName">{{scope.row.userName}}</p>
              <p v-else>--</p>
            </template>
          </el-table-column>
          <el-table-column
            prop="amount"
            label="充币数量"
            align="center"
          >

          </el-table-column>
          <el-table-column
            prop="amount"
            label="确认数量"
            align="center"
          >

          </el-table-column>
          <el-table-column
            label="申请时间"
            align="center"
          >
            <template slot-scope="scope">
              {{scope.row.createTime | formatTime}}
            </template>
          </el-table-column>
          <el-table-column
            label="完成时间"
            align="center"
          >
            <template slot-scope="scope">
              {{scope.row.updateTime | formatTime}}
            </template>
          </el-table-column>
          <!-- <el-table-column
            label="录入客服"
            align="center"
          >

          </el-table-column> -->
          <el-table-column
            prop="status"
            label="状态"
            align="center"
          >
            <template slot-scope="scope">
              <p v-if="scope.row.status" class="success">已完成</p>
            </template>
          </el-table-column>
        </el-table>
      </el-row>
      <el-row
        type="flex"
        justify="center"
      >
        <el-pagination
          @current-change="handleCurrentChange"
          :current-page.sync="searchContent.pageNum"
          :page-size="searchContent.pageSize"
          layout="total, prev, pager, next"
          :total="totalSize"
        >
        </el-pagination>
      </el-row>
    </section>

    <el-dialog
      title="手工入币："
      :visible="addCoinInVisibleDialog"
      width="400px"
      @close="handleAddCoinInClose"
    >
      <el-form label-width="90px">
        <el-form-item label="哈希值：">
          <el-input></el-input>
        </el-form-item>
        <el-form-item label="地址：">
          <el-input></el-input>
        </el-form-item>
        <el-form-item label="UID：">
          <el-input></el-input>
        </el-form-item>
        <el-form-item label="充币数量：">
          <el-input></el-input>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import { getRequestData, rechargeList } from "@/api/requestMethods";
import { formatTime } from "@/api/dateUtil";
import { clearSearchContent } from "@/api/searchUtil";
export default {
  data() {
    return {
      searchContent: {
        searchKey: "",
        pageNum: 1,
        pageSize: 10,
        status: "",
        startTime: "",
        endTime: ""
      },

      searchBoolean: false,
      ciData: [],
      totalSize: 0,

      createTime: [],

      addCoinInVisibleDialog: false
    };
  },
  methods: {
    requestData() {
      let data = getRequestData();
      if (!this.searchBoolean) {
        this.searchContent = clearSearchContent(this.searchContent);
      }
      data.body = this.searchContent;
      rechargeList(data)
        .then(res => {
          if (res.data.rtnCode == 1) {
            if (res.data.data) {
              this.totalSize = res.data.data.total;
              this.ciData = res.data.data.records;
            }
          }
        })
        .catch(err => {
          this.$notify({
            title: "失败",
            message: "网络不好，请稍后再试！",
            type: "error",
            offset: 128
          });
        });
    },
    handleSearch() {
      this.searchContent.pageNum = 1;
      this.searchBoolean = true;
      this.requestData();
    },
    resetSearchContent() {
      this.searchContent.searchKey = "";
      this.searchContent.startTime = "";
      this.searchContent.endTime = "";
      this.createTime = [];
    },
    handleCurrentChange() {
      this.requestData();
    },
    handleDateChange() {
      if (this.createTime) {
        let startTime = new Date(this.createTime[0]).getTime();
        let endTime = new Date(this.createTime[1]).getTime() + 24 * 60 * 60 * 1000;
        this.searchContent.startTime = startTime;
        this.searchContent.endTime = endTime;
      } else {
        this.searchContent.startTime = "";
        this.searchContent.endTime = "";
      }
    },

    handleAddCoinInClose() {
      this.addCoinInVisibleDialog = false;
    }
  },
  mounted() {
    this.requestData();
    this.$store.commit("updateHeaderName", "充币记录");
    this.$store.commit("updateDefaultActive", "5-2");
  },
  filters: {
    formatTime(time) {
      let date = new Date(time);
      return formatTime(date, "yyyy-MM-dd hh:mm:ss");
    }
  }
};
</script>

<style scoped>
.coinIn_container {
}
.coinIn_container .search_container > ul > li {
  font-size: 14px;
  color: #909399;
  margin-right: 15px;
  font-weight: bold;
}
.coinIn_container .search_container > ul > li:nth-of-type(1) .el-input {
  width: 150px;
  margin-right: 10px;
}
.coinIn_container .search_container > ul > li .el-select {
  width: 150px;
}
.coinIn_container .main_container {
  margin-top: 15px;
}
.coinIn_container .main_container .el-row {
  margin-bottom: 15px;
}
</style>
