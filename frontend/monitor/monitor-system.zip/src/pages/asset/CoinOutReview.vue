<template>
  <div class="coinOutReview_container">
    <section class="search_container">
      <ul style="display: flex;justify-content: start;">
        <li>
          <el-input
            v-model="searchContent.searchKey"
            placeholder="UID/姓名"
          ></el-input>
        </li>
        <li>
          日期：<el-date-picker
            v-model="createTime"
            type="daterange"
            range-separator="-"
            unlink-panels
            start-placeholder="起始日期"
            end-placeholder="截至日期"
            @change="handleDateChange"
          >
          </el-date-picker>
        </li>
        <li>
          <el-button-group>
            <el-button
              type="primary"
              @click="handleSearch"
            ><i class="el-icon-search"></i></el-button>
            <el-button
              type="primary"
              @click="resetSearchContent"
            ><i class="el-icon-refresh"></i></el-button>
          </el-button-group>
        </li>
      </ul>
    </section>
    <section class="main_container">
      <el-row>
        <el-table
          :data="corData"
          ref="corTable"
        >
          <el-table-column
            prop="id"
            label="流水编号"
            width="80"
          >

          </el-table-column>
          <el-table-column
            prop="gmId"
            label="UID"
            align="center"
          >

          </el-table-column>
          <el-table-column
            prop="userName"
            label="姓名"
            align="center"
          >
            <template slot-scope="scope">
              <p v-if="scope.row.userName">{{scope.row.userName}}</p>
              <p v-else>--</p>
            </template>
          </el-table-column>
          <el-table-column
            prop="phone"
            label="手机号"
            align="center"
            width="120"
          >

          </el-table-column>
          <el-table-column
            prop="amount"
            label="提币数量"
            align="center"
          >
          </el-table-column>
          <el-table-column
            prop="outerAddress"
            label="对方地址"
            align="center"
            width="330"
          >
          </el-table-column>
          <el-table-column
            label="提交时间"
            align="center"
            width="200"
          >
            <template slot-scope="scope">
              <p>{{scope.row.createTime | formatTime}}</p>
            </template>
          </el-table-column>
          <el-table-column
            label="操作"
            align="center"
            width="150"
          >
            <template slot-scope="scope">
              <el-button
                size="mini"
                type="primary"
                @click="reviewCoinOut(scope.$index, scope.row)"
              >审核</el-button>
              <el-button
                size="mini"
                type="danger"
                @click="cancelCoinOut(scope.$index, scope.row)"
              >撤销</el-button>
            </template>

          </el-table-column>
        </el-table>
      </el-row>
      <el-row
        type="flex"
        justify="center"
      >
        <el-pagination
          @current-change="handleCurrentChange"
          :current-page.sync="searchContent.pageNum"
          :page-size="searchContent.pageSize"
          layout="total, prev, pager, next"
          :total="totalSize"
        >
        </el-pagination>
      </el-row>
    </section>
  </div>
</template>

<script>
import {
  getRequestData,
  withdrawList,
  withdrawAuditing,
  withdrawCancel
} from "@/api/requestMethods";
import { formatTime } from "@/api/dateUtil";
import { clearSearchContent } from "@/api/searchUtil";
export default {
  data() {
    return {
      searchContent: {
        searchKey: "",
        pageNum: 1,
        pageSize: 10,
        startTime: "",
        endTime: ""
      },

      createTime: [],

      searchBoolean: false,
      corData: [],
      totalSize: 0,

      addBlacklistVisibleDialog: false
    };
  },
  methods: {
    requestData() {
      let data = getRequestData();
      if (!this.searchBoolean) {
        this.searchContent = clearSearchContent(this.searchContent);
      }
      data.body = this.searchContent;
      withdrawList(data)
        .then(res => {
          if (res.data.rtnCode == 1) {
            if (res.data.data) {
              this.totalSize = res.data.data.total;
              this.corData = res.data.data.records;
            }
          }
        })
        .catch(err => {
          this.$notify({
            title: "失败",
            message: "网络不好，请稍后再试！",
            type: "error",
            offset: 128
          });
        });
    },
    handleSearch() {
      this.searchContent.pageNum = 1;
      this.searchBoolean = true;
      this.requestData();
    },
    resetSearchContent() {
      this.searchContent.searchKey = "";
      this.searchContent.startTime = "";
      this.searchContent.endTime = "";
      this.createTime = [];
    },
    handleCurrentChange() {
      this.requestData();
    },
    handleDateChange() {
      if (this.createTime) {
        let startTime = new Date(this.createTime[0]).getTime();
        let endTime =
          new Date(this.createTime[1]).getTime() + 24 * 60 * 60 * 1000;
        this.searchContent.startTime = startTime;
        this.searchContent.endTime = endTime;
      } else {
        this.searchContent.startTime = "";
        this.searchContent.endTime = "";
      }
    },
    reviewCoinOut(index, row) {
      this.$confirm("确认通过 " + row.gmId + " ， " + row.phone + " 提 " + row.amount + " TWITTER的申请吗？", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          let data = getRequestData();
          data.body = {
            id: row.id
          };
          withdrawAuditing(data)
            .then(res => {
              if (res.data.rtnCode == 1) {
                this.$notify({
                  title: "成功",
                  message: "审核成功！",
                  type: "success",
                  offset: 128
                });
                this.corData.splice(index, 1);
              } else {
                this.$notify({
                  title: "失败",
                  message: "审核失败！",
                  type: "error",
                  offset: 128
                });
              }
            })
            .catch(err => {
              this.$notify({
                title: "失败",
                message: "网络不好，请稍后再试！",
                type: "error",
                offset: 128
              });
            });
        })
        .catch(() => {});
    },
    cancelCoinOut(index, row) {
      this.$confirm("请确认是否撤销该条提币记录?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          let data = getRequestData();
          data.body = {
            id: row.id
          };
          withdrawCancel(data)
            .then(res => {
              if (res.data.rtnCode == 1) {
                this.$notify({
                  title: "成功",
                  message: "撤销成功！",
                  type: "success",
                  offset: 128
                });
                this.corData.splice(index, 1);
              } else {
                this.$notify({
                  title: "失败",
                  message: "撤销失败！",
                  type: "error",
                  offset: 128
                });
              }
            })
            .catch(err => {
              this.$notify({
                title: "失败",
                message: "网络不好，请稍后再试！",
                type: "error",
                offset: 128
              });
            });
        })
        .catch(() => {});
    }
  },
  mounted() {
    this.requestData();
    this.$store.commit("updateHeaderName", "提币审核");
    this.$store.commit("updateDefaultActive", "5-3");
  },
  filters: {
    formatTime(time) {
      let date = new Date(time);
      return formatTime(date, "yyyy-MM-dd hh:mm:ss");
    }
  }
};
</script>

<style scoped>
.coinOutReview_container {
}
.coinOutReview_container .search_container > ul > li {
  font-size: 14px;
  color: #909399;
  margin-right: 15px;
  font-weight: bold;
}
.coinOutReview_container .search_container > ul > li:nth-of-type(1) .el-input {
  width: 150px;
}
.coinOutReview_container .main_container {
  margin-top: 15px;
}
.coinOutReview_container .main_container .el-row {
  margin-bottom: 15px;
}
</style>
