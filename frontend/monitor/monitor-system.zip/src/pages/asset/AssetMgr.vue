<template>
  <div class="assetMgr_container">
    <section class="search_container">
      <ul style="display: flex;justify-content: start;">
        <li>
          UID：<el-input v-model="searchContent.searchKey"></el-input>
        </li>
        <li>
          <el-button-group>
            <el-button
              type="primary"
              @click="handleSearch"
            ><i class="el-icon-search"></i></el-button>
            <el-button
              type="primary"
              @click="resetSearchContent"
            ><i class="el-icon-refresh"></i></el-button>
          </el-button-group>
        </li>
      </ul>
    </section>
    <section class="main_container">
      <el-row>
        <el-col :span="10">

          <el-table
            :data="assetsData"
            ref="assetsTable"
          >
            <el-table-column
              prop="gmId"
              label="UID"
              align="center"
            >

            </el-table-column>
            <el-table-column
              label="姓名"
              align="center"
            >
              <template slot-scope="scope">
                <p v-if="scope.row.name">{{scope.row.name}}</p>
                <p v-else>--</p>
              </template>
            </el-table-column>
            <el-table-column
              prop="assets"
              label="TWITTER数量"
              align="center"
            >

            </el-table-column>
          </el-table>
        </el-col>
      </el-row>
      <el-row type="flex">
        <el-col
          :span="10"
          style="text-align:center;"
        >
          <el-pagination
            @current-change="handleCurrentChange"
            :current-page.sync="searchContent.pageNum"
            :page-size="searchContent.pageSize"
            layout="total, prev, pager, next"
            :total="totalSize"
          >
          </el-pagination>
        </el-col>
      </el-row>
    </section>
  </div>
</template>

<script>
import { getRequestData, assetList } from "@/api/requestMethods";
import { formatTime } from "@/api/dateUtil";
import { clearSearchContent } from "@/api/searchUtil";
export default {
  data() {
    return {
      searchContent: {
        searchKey: "",
        pageNum: 1,
        pageSize: 10
      },

      searchBoolean: false,
      assetsData: [],
      totalSize: 0
    };
  },
  methods: {
    requestData() {
      let data = getRequestData();
      if (!this.searchBoolean) {
        this.searchContent = clearSearchContent(this.searchContent);
      }
      data.body = this.searchContent;
      assetList(data)
        .then(res => {
          if (res.data.rtnCode == 1 && res.data.data) {
            this.totalSize = res.data.data.total;
            this.assetsData = res.data.data.records;
          }
        })
        .catch(err => {
          this.$notify({
            title: "失败",
            message: "网络不好，请稍后再试！",
            type: "error",
            offset: 128
          });
        });
    },
    handleSearch() {
      this.searchContent.pageNum = 1;
      this.searchBoolean = true;
      this.requestData();
    },
    resetSearchContent() {
      this.searchContent.searchKey = "";
    },
    handleCurrentChange() {
      this.requestData();
    }
  },
  mounted() {
    this.requestData();
    this.$store.commit("updateHeaderName", "资产管理");
    this.$store.commit("updateDefaultActive", "5-1");
  },
  filters: {
    formatTime(time) {
      let date = new Date(time);
      return formatTime(date, "yyyy-MM-dd hh:mm:ss");
    }
  }
};
</script>

<style scoped>
.assetMgr_container {
}
.assetMgr_container .search_container > ul > li {
  font-size: 14px;
  color: #909399;
  margin-right: 15px;
  font-weight: bold;
}
.assetMgr_container .search_container > ul > li:nth-of-type(1) .el-input {
  width: 150px;
}
.assetMgr_container .main_container {
  margin-top: 15px;
}
.assetMgr_container .main_container .el-row {
  margin-bottom: 15px;
}
</style>
