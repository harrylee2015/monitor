<template>
    <div style="manager_content">
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>
.manager_content{
    width: 100%;
    overflow: auto;
}
</style>
