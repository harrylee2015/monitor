<template>
  <el-container
    class="manager_wrap"
    ref="layout"
  >
    <el-header class="manager_header">
      <manager-header></manager-header>
    </el-header>
    <!-- <el-container class="manager_container">
      <el-aside class="layout_aside">
        <side-bar class="manager-side-bar"></side-bar>
      </el-aside>
      <el-container>
        <el-header class="nav_container">
          <nav-bar :refresh="reload"></nav-bar>
        </el-header>
        <el-main class="main_container">
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container> -->
    <router-view></router-view>
  </el-container>
</template>

<script>
import managerHeader from "../../components/ManagerHeader";
import sideBar from "../../components/SideBar";
import navBar from "../../components/NavBar";
export default {
  inject: ["reload"],
  components: {
    "manager-header": managerHeader,
    "side-bar": sideBar,
    "nav-bar": navBar
  }
};
</script>

<style scoped>
.manager_wrap {
  width: 960px;
  height: 2000px;
  background: url("../../../static/img/background.png") top center no-repeat;
  flex: 0 0 960px;
}
.manager_header {
  margin-top: 5px;
  height: 95px !important;
  background: transparent;
  width: 950px;
}
.manager_container {
  height: calc(100vh - 80px);
}
.layout_aside {
  width: 200px !important;
  background: #222d32;
}
.manager-side-bar {
  width: 100%;
}
.nav_container {
  padding: 0;
  height: 56px !important;
}
.main_container {
  padding: 30px 80px;
  overflow: auto;
}
.footer_container {
  padding: 0;
}
</style>
