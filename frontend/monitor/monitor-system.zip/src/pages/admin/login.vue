<template>
    <div class="login_container" v-loading.fullscreen.lock="loading" element-loading-text="登录中..." element-loading-background="rgba(0, 0, 0, 0.8)">
        <div>
            <section class="title">
                推特链管理后台
            </section>
            <section class="form">
                <el-form ref="form" :model="user" :rules="loginRules">
                    <el-form-item label="" prop="username">
                        <el-input v-model="user.username" placeholder="账号"></el-input>
                    </el-form-item>
                    <el-form-item label="" prop="password">
                        <el-input type="password" v-model="user.password" placeholder="密码" @keydown.enter.native="onSubmit($event)"></el-input>
                    </el-form-item>
                    <el-form-item>
                        <input type="button" value="登 录" class="loginButton" @click="onSubmit" />
                    </el-form-item>
                </el-form>
            </section>
        </div>
    </div>
</template>

<script>
import { getRequestData, adminLogin } from "@/api/requestMethods";
export default {
  data() {
    var validateUsername = (rule, value, callback) => {
      if (!value) {
        callback(new Error("请输入用户名"));
      }
      callback();
    };
    var validatePassword = (rule, value, callback) => {
      if (!value) {
        callback(new Error("请输入密码"));
      }
      callback();
    };
    return {
      user: {
        username: "",
        password: ""
      },
      loginRules: {
        username: [{ validator: validateUsername, trigger: "blur" }],
        password: [{ validator: validatePassword, trigger: "blur" }]
      },
      loading: false
    };
  },
  methods: {
    onSubmit() {
      this.$refs.form.validate(valid => {
        if (valid) {
          let data = getRequestData();
          data.body = this.user;
          adminLogin(data)
            .then(res => {
              if (res.data.rtnCode === 1) {
                this.$cookies.set("id", res.data.data.uid, "1d");
                this.$cookies.set("f", res.data.data.token, "1d");
                this.$cookies.set("account", res.data.data.uid, "1d");
                this.$router.push({ name: "user-info" });
                this.$notify({
                  title: "成功",
                  message: "欢迎你，" + res.data.data.uid + "！",
                  type: "success",
                  offset: 128
                });
              } else {
                this.$notify({
                  title: "失败",
                  message: "账号或密码错误！",
                  type: "error",
                  offset: 100
                });
              }
            })
            .catch(err => {
              this.$notify({
                title: "失败",
                message: "网络不好，请稍后再试！",
                type: "error",
                offset: 100
              });
            });
        } else {
          return false;
        }
      });
    }
  }
};
</script>

<style scoped>
.login_container {
  box-sizing: border-box;
  width: 100vw;
  height: 100vh;
  background-image: url("../../../static/img/loginBg.png");
  background-size: 100% 100%;
}
.login_container > div {
  padding: 8vh 0 0vh 5.98vw;
}
.login_container section.title {
  font-size: 3.75vw;
  color: rgba(206, 87, 9, 1);
  margin-bottom: 7vh;
}
.login_container section.form {
  width: 550px;
  margin: 0 auto;
  background-image: url("../../../static/img/loginFormBg.png");
  background-size: 100% 100%;
  padding: 9vh 0;
}
.login_container section.form > form {
  width: 385px;
  margin: 0 auto;
}
.loginButton {
  height: 52.6px;
  width: 385px;
  background-image: url("../../../static/img/loginBtn.png");
  background-size: 100% 100%;
  border-radius: 20px;
  border: none;
  outline: none;
  color: #fff;
  font-weight: bold;
  font-size: 20px;
}
.loginButton:hover {
  cursor: pointer;
}
</style>
