<template>
  <div class="declarationMgr_container">
    <section class="search_container">
      <ul style="display: flex;justify-content: start;">
        <li>
          <el-input
            v-model="searchContent.searchKey"
            placeholder="UID/姓名"
          ></el-input>
        </li>
        <li>
          日期：<el-date-picker
            v-model="createTime"
            type="daterange"
            range-separator="-"
            unlink-panels
            start-placeholder="起始日期"
            end-placeholder="截至日期"
            @change="handleDateChange"
          >
          </el-date-picker>
        </li>
        <li>
          <el-button-group>
            <el-button
              type="primary"
              @click="handleSearch"
            ><i class="el-icon-search"></i></el-button>
            <el-button
              type="primary"
              @click="resetSearchContent"
            ><i class="el-icon-refresh"></i></el-button>
          </el-button-group>
        </li>
      </ul>
    </section>
    <section class="main_container">
      <el-row>
        <el-table
          :data="dmsData"
          ref="dmsTable"
          @sort-change="handleSortChange"
        >
          <el-table-column
            prop="originator"
            label="发起人UID"
            width="100"
          >

          </el-table-column>
          <el-table-column
            prop="originatorName"
            label="发起人姓名"
            align="center"
          >
            <template slot-scope="scope">
              <p v-if="scope.row.originatorName">{{scope.row.originatorName}}</p>
              <p v-else>--</p>
            </template>
          </el-table-column>
          <el-table-column
            prop="receiver"
            label="对方UID"
            align="center"
          >
            <template slot-scope="scope">
              <p v-if="scope.row.receiver">{{scope.row.receiver}}</p>
              <p v-else>--</p>
            </template>
          </el-table-column>
          <el-table-column
            prop="receiverName"
            label="对方姓名"
            align="center"
          >
            <template slot-scope="scope">
              <p v-if="scope.row.receiverName">{{scope.row.receiverName}}</p>
              <p v-else>--</p>
            </template>
          </el-table-column>
          <el-table-column
            label="是否情侣"
            align="center"
          >
            <template slot-scope="scope">
              <p v-if="scope.row.ifLovers == 1">是</p>
              <p v-else>否</p>
            </template>
          </el-table-column>
          <el-table-column
            prop="createTime"
            label="发布时间"
            sortable="custom"
            align="center"
            width="200"
          >
            <template slot-scope="scope">
              {{scope.row.createTime | formatTime}}
            </template>
          </el-table-column>
          <el-table-column
            label="发布内容"
            align="center"
          >
            <template slot-scope="scope">
              <el-button
                size="mini"
                type="primary"
                @click="seeDetails(scope.$index, scope.row)"
              >点击查看</el-button>
            </template>
          </el-table-column>
          <el-table-column
            prop="reportNum"
            label="被举报次数"
            sortable="custom"
            align="center"
          >
            <template slot-scope="scope">
              <p v-if="scope.row.reportNum >= 0 && scope.row.reportNum <= 10">{{scope.row.reportNum}}</p>
              <p
                v-if="scope.row.reportNum >= 11 && scope.row.reportNum <= 30"
                class="warning"
              >{{scope.row.reportNum}}</p>
              <p
                v-if="scope.row.reportNum >= 31"
                class="error"
              >{{scope.row.reportNum}}</p>
            </template>
          </el-table-column>
          <el-table-column
            label="操作"
            align="center"
          >
            <template slot-scope="scope">
              <el-button
                size="mini"
                type="danger"
                @click="delDeclaration(scope.$index, scope.row)"
              >删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-row>
      <el-row
        type="flex"
        justify="center"
      >
        <el-pagination
          @current-change="handleCurrentChange"
          :current-page.sync="searchContent.pageNum"
          :page-size="searchContent.pageSize"
          layout="total, prev, pager, next"
          :total="totalSize"
        >
        </el-pagination>
      </el-row>
    </section>

    <el-dialog
      title="宣言详情"
      :visible="detailDialogVisible"
      width="450px"
      center
      @close = "handleDetailClose"
    >
      <!-- <el-row :gutter="6" type="flex" justify="center"> -->
        <!-- <el-col :span="6" v-for="imgUrl of detailImgUrls" :key="imgUrl">
          <img :src="imgUrl" style="width:100%"/>
        </el-col> -->

        <el-carousel :interval="4000" type="card" height="250px" style="min-width:400px" v-if="detailImgUrls.length != 0">
          <el-carousel-item v-for="imgUrl of detailImgUrls" :key="imgUrl" style="min-width:400px">
              <img :src="imgUrl" height="250px"/>
          </el-carousel-item>
        </el-carousel>
        <!-- <span style="width:100%">
          <img :src="imgUrl" v-for="imgUrl of detailImgUrls" :key="imgUrl" style="height:200px;"/>
        </span> -->
        
      <!-- </el-row> -->
      <!-- <span><img :src="detailImgUrl" style="height:300px"/></span> -->
      <span style="margin-top:20px;font-size:15px;">{{detailContent}}</span>
    </el-dialog>

  </div>
</template>

<script>
import {
  getRequestData,
  declareList,
  deleteDeclare,
  declareDetail
} from "@/api/requestMethods";
import { formatTime } from "@/api/dateUtil";
import { clearSearchContent } from "@/api/searchUtil";
export default {
  data() {
    return {
      createTime: [],
      searchContent: {
        searchKey: "",
        startTime: "",
        endTime: "",
        timeOrder: "",
        reportOrder: "",
        pageNum: 1,
        pageSize: 10
      },

      searchBoolean: false,
      dmsData: [],
      totalSize: 0,

      detailDialogVisible: false,
      detailImgUrls: [],
      detailContent: "",
    };
  },
  methods: {
    requestData() {
      let data = getRequestData();
      if (!this.searchBoolean) {
        this.searchContent = clearSearchContent(this.searchContent);
      }
      data.body = this.searchContent;
      declareList(data)
        .then(res => {
          if (res.data.rtnCode == 1) {
            if (res.data.data) {
              this.totalSize = res.data.data.total;
              this.dmsData = res.data.data.records;
            }
          }
        })
        .catch(err => {
          this.$notify({
            title: "失败",
            message: "网络不好，请稍后再试！",
            type: "error",
            offset: 128
          });
        });
    },
    handleSearch() {
      this.searchContent.pageNum = 1;
      if (
        this.searchContent.searchKey.length == 0 &&
        this.searchContent.startTime.length == 0 &&
        this.searchContent.endTime.length == 0
      ) {
        this.searchBoolean = false;
      } else {
        this.searchBoolean = true;
      }
      this.requestData();
    },
    resetSearchContent() {
      this.searchContent.searchKey = "";
      this.searchContent.startTime = "";
      this.searchContent.endTime = "";
      this.createTime = [];
    },
    handleCurrentChange() {
      this.requestData();
    },
    handleSortChange(table) {
      let value = "";
      if (table.order == "ascending") {
        value = 1;
      } else if (table.order == "descending") {
        value = 0;
      } else {
        value = "";
      }
      if (table.prop == "createTime") {
        this.searchContent.timeOrder = value;
      } else if (table.prop == "reportNum") {
        this.searchContent.reportOrder = value;
      } else {
        this.searchContent.timeOrder = "";
        this.searchContent.reportOrder = "";
      }
      this.searchContent.pageNum = 1;
      this.requestData();
    },
    handleDateChange() {
      if (this.createTime) {
        let startTime = new Date(this.createTime[0]).getTime();
        let endTime =
          new Date(this.createTime[1]).getTime() + 24 * 60 * 60 * 1000;
        this.searchContent.startTime = startTime;
        this.searchContent.endTime = endTime;
      } else {
        this.searchContent.startTime = "";
        this.searchContent.endTime = "";
      }
    },

    seeDetails(index, row) {
      let data = getRequestData();
      data.body = {
        id: row.id
      };
      declareDetail(data)
        .then(res => {
          if(res.data.rtnCode == 1){
            let resdata = res.data.data;
            if(resdata.images != null ){
              let imgArr = resdata.images.split(",");
              for(let imgUrl of imgArr){
                this.detailImgUrls.push(imgUrl);
              }
            }else if(resdata.videos != null){
              for(let imgUrl of resdata.videos){
                this.detailImgUrls.push(imgUrl.previewUrl);
              }
            }
            this.detailContent = resdata.content
          }
        })
        .catch(err => {
          console.log(err);
        });
      this.detailDialogVisible = true;
    },
    handleDetailClose(){
      this.detailDialogVisible = false;
      this.detailImgUrls = [];
      this.detailContent = "";
    },

    delDeclaration(index, row) {
      this.$confirm(
        "真的要删除用户“" + row.originatorName + "”发起的宣言吗？",
        "提示",
        {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }
      )
        .then(() => {
          let data = getRequestData();
          data.body = {
            id: row.id
          };
          deleteDeclare(data)
            .then(res => {
              if (res.data.rtnCode == 1) {
                this.$notify({
                  title: "成功",
                  message: "删除成功！",
                  type: "success",
                  offset: 128
                });
                this.requestData();
              }
            })
            .catch(err => {
              this.$notify({
                title: "失败",
                message: "网络不好，请稍后再试！",
                type: "error",
                offset: 128
              });
            });
        })
        .catch(() => {});
    }
  },
  mounted() {
    this.requestData();
    this.$store.commit("updateHeaderName", "宣言管理");
    this.$store.commit("updateDefaultActive", "2-1");
  },
  filters: {
    formatTime(time) {
      let date = new Date(time);
      return formatTime(date, "yyyy-MM-dd hh:mm:ss");
    }
  }
};
</script>

<style scoped>
.declarationMgr_container {
}
.declarationMgr_container .search_container > ul > li {
  font-size: 14px;
  color: #909399;
  margin-right: 15px;
  font-weight: bold;
}
.declarationMgr_container .search_container > ul > li:nth-of-type(1) .el-input {
  width: 200px;
}
.declarationMgr_container
  .search_container
  > ul
  > li:nth-of-type(2)
  .el-date-editor {
  width: 300px;
}
.declarationMgr_container
  .search_container
  > ul
  > li:nth-of-type(3)
  .el-select {
  width: 120px;
}
.declarationMgr_container .main_container {
  margin-top: 15px;
}
.declarationMgr_container .main_container .el-row {
  margin-bottom: 15px;
}
.sort_label {
  float: left;
}
.sort_icon {
  float: right;
  color: #8492a6;
}
</style>
