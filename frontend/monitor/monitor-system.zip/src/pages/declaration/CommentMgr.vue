<template>
  <div class="cMgr_container">
    <section class="search_container">
      <ul style="display: flex;justify-content: start;">
        <li>
          <el-input
            v-model="searchContent.selectValue"
            placeholder="UID/姓名/手机号"
          ></el-input>
        </li>
        <li>
          日期：<el-date-picker
            v-model="createTime"
            type="daterange"
            range-separator="-"
            unlink-panels
            start-placeholder="起始日期"
            end-placeholder="截至日期"
            @change="handleDateChange"
          >
          </el-date-picker>
        </li>
        <li>
          <el-button-group>
            <el-button
              type="primary"
              @click="handleSearch"
            ><i class="el-icon-search"></i></el-button>
            <el-button
              type="primary"
              @click="resetSearchContent"
            ><i class="el-icon-refresh"></i></el-button>
          </el-button-group>
        </li>
      </ul>
    </section>
    <section class="main_container">
      <el-row>
        <el-table
          :data="cMgrData"
          ref="cMgrTable"
        >
          <el-table-column
            prop="uid"
            label="用户UID"
            align="center"
            width="100"
          >

          </el-table-column>
          <el-table-column
            prop="userName"
            label="姓名"
            align="center"
            width="100"
          >
            <template slot-scope="scope">
              <p v-if="scope.row.userName">{{scope.row.userName}}</p>
              <p v-else>--</p>
            </template>
          </el-table-column>
          <el-table-column
            prop="phone"
            label="手机号"
            align="center"
            width="120"
          >

          </el-table-column>
          <el-table-column
            prop="comment"
            label="评论内容"
            align="center"
          >
          </el-table-column>
          <el-table-column
            label="被评论的宣言"
            align="center"
          >
            <template slot-scope="scope">
              <p v-if="scope.row.declare">{{scope.row.declare}}</p>
              <p v-else>--</p>
            </template>
          </el-table-column>
          <el-table-column
            label="被回复的内容"
            align="center"
          >
            <template slot-scope="scope">
              <p v-if="scope.row.reply">{{scope.row.reply}}</p>
              <p v-else>--</p>
            </template>
          </el-table-column>
          <el-table-column
            label="发布日期"
            align="center"
            width="200"
          >
            <template slot-scope="scope">
              <p>{{scope.row.time | formatTime}}</p>
            </template>
          </el-table-column>
          <!-- <el-table-column
            prop="count"
            label="举报次数"
            align="center"
            width="100"
          >
          </el-table-column> -->
          <el-table-column
            label="操作"
            align="center"
            width="150"
          >
            <template slot-scope="scope">
              <el-button
                size="mini"
                type="danger"
                @click="deleteComment(scope.$index, scope.row)"
              >删除</el-button>
              <el-button
                size="mini"
                type="warning"
                @click="forbidAccount(scope.$index, scope.row)"
              >禁言</el-button>
            </template>

          </el-table-column>
        </el-table>
      </el-row>
      <el-row
        type="flex"
        justify="center"
      >
        <el-pagination
          @current-change="handleCurrentChange"
          :current-page.sync="searchContent.pageNumber"
          :page-size="searchContent.pageSize"
          layout="total, prev, pager, next"
          :total="totalSize"
        >
        </el-pagination>
      </el-row>
    </section>
  </div>
</template>

<script>
import {
  getRequestData,
  commentList,
  commentDelete,
  commentForbid
} from "@/api/requestMethods";
import { formatTime } from "@/api/dateUtil";
import { clearSearchContent } from "@/api/searchUtil";
export default {
  data() {
    return {
      searchContent: {
        selectValue: "",
        pageNumber: 1,
        pageSize: 10,
        startTime: "",
        endTime: ""
      },

      createTime: [],

      searchBoolean: false,
      cMgrData: [],
      totalSize: 0,

    };
  },
  methods: {
    requestData() {
      let data = getRequestData();
      if (!this.searchBoolean) {
        this.searchContent = clearSearchContent(this.searchContent);
      }
      data.body = this.searchContent;
      commentList(data)
        .then(res => {
          if (res.data.rtnCode == 1) {
            if (res.data.data) {
              this.totalSize = res.data.data.total;
              this.cMgrData = res.data.data.commentArr;
            }
          }
        })
        .catch(err => {
          this.$notify({
            title: "失败",
            message: "网络不好，请稍后再试！",
            type: "error",
            offset: 128
          });
        });
    },
    handleSearch() {
      this.searchContent.pageNumber = 1;
      this.searchBoolean = true;
      this.requestData();
    },
    resetSearchContent() {
      this.searchContent.searchKey = "";
      this.searchContent.startTime = "";
      this.searchContent.endTime = "";
      this.createTime = [];
    },
    handleCurrentChange() {
      this.requestData();
    },
    handleDateChange() {
      if (this.createTime) {
        let startTime = new Date(this.createTime[0]).getTime();
        let endTime =
          new Date(this.createTime[1]).getTime() + 24 * 60 * 60 * 1000;
        this.searchContent.startTime = startTime;
        this.searchContent.endTime = endTime;
      } else {
        this.searchContent.startTime = "";
        this.searchContent.endTime = "";
      }
    },
    deleteComment(index, row) {
      this.$confirm("确认删除用户 " + row.uid + "：" + row.comment + " 的评论吗？", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          let data = getRequestData();
          data.body = {
            id: row.id,
            commentLevel: row.commentLevel
          };
          commentDelete(data)
            .then(res => {
              if (res.data.rtnCode == 1) {
                this.$notify({
                  title: "成功",
                  message: "删除成功！",
                  type: "success",
                  offset: 128
                });
                this.requestData();
              } else {
                this.$notify({
                  title: "失败",
                  message: "删除失败！",
                  type: "error",
                  offset: 128
                });
              }
            })
            .catch(err => {
              this.$notify({
                title: "失败",
                message: "网络不好，请稍后再试！",
                type: "error",
                offset: 128
              });
            });
        })
        .catch(() => {});
    },
    forbidAccount(index, row) {
      this.$confirm("请确认是否禁言用户 " + row.uid + " ？", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          let data = getRequestData();
          data.body = {
            uid: row.uid
          };
          commentForbid(data)
            .then(res => {
              if (res.data.rtnCode == 1) {
                this.$notify({
                  title: "成功",
                  message: "操作成功！",
                  type: "success",
                  offset: 128
                });
                this.requestData();
              } else {
                this.$notify({
                  title: "失败",
                  message: "操作失败！",
                  type: "error",
                  offset: 128
                });
              }
            })
            .catch(err => {
              this.$notify({
                title: "失败",
                message: "网络不好，请稍后再试！",
                type: "error",
                offset: 128
              });
            });
        })
        .catch(() => {});
    }
  },
  mounted() {
    this.requestData();
    this.$store.commit("updateHeaderName", "评论管理");
    this.$store.commit("updateDefaultActive", "2-2");
  },
  filters: {
    formatTime(time) {
      let date = new Date(time);
      return formatTime(date, "yyyy-MM-dd hh:mm:ss");
    }
  }
};
</script>

<style scoped>
.cMgr_container {
}
.cMgr_container .search_container > ul > li {
  font-size: 14px;
  color: #909399;
  margin-right: 15px;
  font-weight: bold;
}
.cMgr_container .search_container > ul > li:nth-of-type(1) .el-input {
  width: 150px;
}
.cMgr_container .main_container {
  margin-top: 15px;
}
.cMgr_container .main_container .el-row {
  margin-bottom: 15px;
}
</style>
