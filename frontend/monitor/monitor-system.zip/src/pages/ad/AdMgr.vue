<template>
  <div class="adMgr_container">
    <section class="main_container">
      <el-row v-loading="loading">

        <el-form
          label-width="100px"
          :model="adv"
          ref="adForm"
        >
          <el-form-item label="头 像：" :rules="{ required: true, message: '请选择头像！', trigger: 'change' }" prop="headUrl">
            <el-upload
              class="avatar-uploader"
              :action="uploadUrl"
              :show-file-list="false"
              :on-success="handleAvatarSuccess"
              :before-upload="beforeAvatarUpload"
              :disabled="ifDisable"
              accept="image/gif,image/jpeg,image/jpg,image/bmp,image/png"
            >
              <img
                v-if="adv.headUrl"
                :src="adv.headUrl"
                class="avatar"
              >
              <i
                v-else
                class="el-icon-plus avatar-uploader-icon"
              ></i>
            </el-upload>
          </el-form-item>
          <el-form-item
            label="用户名："
            prop="username"
            :rules="{ required: true, message: '用户名不能为空！', trigger: 'blur' }"
          >
            <el-input
              :maxlength="10"
              :disabled="ifDisable"
              v-model="adv.username"
            ></el-input>
          </el-form-item>
          <el-form-item
            label="内  容："
            prop="content"
            :rules="{ required: true, message: '内容不能为空！', trigger: 'blur' }"
          >
            <el-input
              type="textarea"
              rows="7"
              resize="none"
              :disabled="ifDisable"
              v-model="adv.content"
            ></el-input>
          </el-form-item>
          <el-form-item label="图  片：">
            <el-upload
              class="pic-upload"
              :action="uploadUrl"
              list-type="picture-card"
              :file-list="fileList"
              :limit="9"
              :on-preview="handlePicPreview"
              :on-remove="handlePicRemove"
              :before-upload="handleBefore"
              :on-success="handlePicSuccess"
              :on-exceed="handlePicExceed"
              :disabled="ifDisable"
              multiple
              accept="image/gif,image/jpeg,image/jpg,image/bmp,image/png"
            >
              <i class="el-icon-plus"></i>
            </el-upload>
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              @click="handleButtonClick"
              :disabled="saveDisable"
            >{{this.ifDisable?"编 辑" : "保 存"}}</el-button>
            <el-button
              v-if="!ifDisable && !ifAdd"
              @click="cancleEdit"
            >取 消</el-button>
          </el-form-item>
        </el-form>

      </el-row>
    </section>

    <el-dialog :visible.sync="dialogVisible" top="5vh">
      <img
        width="100%"
        :src="dialogImageUrl"
        alt=""
      >
    </el-dialog>
  </div>
</template>

<script>
import {
  getRequestData,
  advUpload,
  advDetail,
  advAdd,
  advUpdate
} from "@/api/requestMethods";
import { formatTime } from "@/api/dateUtil";
export default {
  data() {
    return {
      fileList: [],
      uploadUrl: this.$store.state.HOST + "upload/adv/",
      dialogImageUrl: "",
      dialogVisible: false,
      ifDisable: true,
      adv: {
        username: "",
        photos: "",
        content: "",
        headUrl: ""
      },
      ifAdd: true,
      loading: true,

      saveDisable: false,
      picUploadState: {}
    };
  },
  methods: {
    requestData() {
      let data = getRequestData();
      advDetail(data)
        .then(res => {
          if (res.data.rtnCode == 1) {
            if (res.data.data) {
              let declareData = res.data.data;
              this.ifAdd = false;
              this.adv.username = declareData.originatorNickName;
              this.adv.content = declareData.content;
              this.adv.headUrl = declareData.originatorHeadUrl;
              this.adv.photos = [];
              this.fileList = [];
              // let imgArr = declareData.images
              //   .substr(1, declareData.images.length - 2)
              //   .split(",");
              let imgArr = [];
              if(declareData.images != null && declareData.images != ""){
                imgArr = declareData.images.split(",");
              }
              for (let image of imgArr) {
                let newImage = {
                  url: image,
                  response: { data: { url: image } }
                };
                this.fileList.push(newImage);
                this.adv.photos.push(image);
              }
            } else {
              this.ifAdd = true;
              this.ifDisable = false;
            }
          }
          setTimeout(() => {
            this.loading = false;
          }, 666);
        })
        .catch(err => {
          this.loading = false;
          this.$notify({
            title: "失败",
            message: "网络不好，请稍后再试！",
            type: "error",
            offset: 128
          });
        });
    },

    handleAvatarSuccess(response, file, fileList) {
      this.adv.headUrl = response.data.url;
      this.updateSavdDisable(file);
    },
    beforeAvatarUpload(file) {
      const isJPG = file.type === "image/jpeg";
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        // this.$message.error("上传头像图片只能是 JPG 格式!");
        this.$notify({
          title: "警告",
          message: "上传头像图片只能是 JPG 格式!",
          type: "warning",
          offset: 128
        });
      }
      if (!isLt2M) {
        // this.$message.error("上传头像图片大小不能超过 2MB!");
        this.$notify({
          title: "警告",
          message: "上传头像图片大小不能超过 2MB!",
          type: "warning",
          offset: 128
        });
      }
      if(isJPG && isLt2M){
        this.saveDisable = true;
        this.picUploadState[file.uid] = false;
      }
      return isJPG && isLt2M;
    },
    handleBefore(file){
      this.saveDisable = true;
      this.picUploadState[file.uid] = false;
    },

    handlePicSuccess(response, file, fileList) {
      this.fileList = fileList;
      this.updateSavdDisable(file);
    },
    updateSavdDisable(file){
      this.picUploadState[file.uid] = true;
      let ret = true;
      let i = 0;
      for(let name in this.picUploadState){
        i++;
        if(!this.picUploadState[name]){
          ret = false;
          break;
        }
      }
      if(i == 0 || ret){
        this.saveDisable = false;
      }
    },
    handlePicRemove(file, fileList) {
      this.fileList = fileList;
      delete this.picUploadState[file.uid];
    },
    handlePicExceed(files, fileList) {
      this.$notify({
        title: "警告",
        message: "最多上传 9 张图片！",
        type: "warning",
        offset: 128
      });
    },
    handlePicPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    handleButtonClick() {
      if (this.ifDisable) {
        this.ifDisable = !this.ifDisable;
        return;
      }
      this.$refs.adForm.validate(valid => {
        if (valid) {
          if (!this.adv.headUrl) {
            this.$notify({
              title: "警告",
              message: "请选择头像！",
              type: "warning",
              offset: 128
            });
            return false;
          }
          // if (this.fileList.length === 0) {
          //   this.$notify({
          //     title: "警告",
          //     message: "请选择照片！",
          //     type: "warning",
          //     offset: 128
          //   });
          //   return false;
          // }
          this.loading = true;
          let urlList = [];
          for (let i = 0; i < this.fileList.length; i++) {
            urlList.push(this.fileList[i].response.data.url);
          }
          this.adv.photos = urlList;
          // if (!this.ifAdd) {
          //   let data = getRequestData();
          //   data.body = this.adv;
          //   advUpdate(data)
          //     .then(res => {
          //       this.loading = false;
          //       if (res.data.rtnCode == 1) {
          //         this.ifDisable = true;
          //         this.$notify({
          //           title: "成功",
          //           message: "保存成功！",
          //           type: "success",
          //           offset: 128
          //         });
          //       }
          //     })
          //     .catch(err => {
          //       this.loading = false;
          //       this.$notify({
          //         title: "失败",
          //         message: "网络不好，请稍后再试！",
          //         type: "error",
          //         offset: 128
          //       });
          //     });
          // } else {
            let data = getRequestData();
            data.body = this.adv;
            advAdd(data)
              .then(res => {
                this.loading = false;
                if (res.data.rtnCode == 1) {
                  this.ifDisable = true;
                  this.ifAdd = false;
                  this.$notify({
                    title: "成功",
                    message: "保存成功！",
                    type: "success",
                    offset: 128
                  });
                }else{
                  this.$notify({
                    title: "失败",
                    message: res.data.errMsg,
                    type: "error",
                    offset: 128
                  });
                }
              })
              .catch(err => {
                this.loading = false;
                this.$notify({
                  title: "失败",
                  message: "网络不好，请稍后再试！",
                  type: "error",
                  offset: 128
                });
              });
          // }
        } else {
          return false;
        }
      });
    },
    cancleEdit() {
      this.loading = true;
      this.ifDisable = true;
      this.requestData();
    }
  },
  mounted() {
    this.requestData();
    this.$store.commit("updateHeaderName", "广告管理");
    this.$store.commit("updateDefaultActive", "7");
  },
  filters: {
    formatTime(time) {
      let date = new Date(time);
      return formatTime(date, "yyyy-MM-dd hh:mm:ss");
    }
  }
};
</script>

<style>
.adMgr_container {
}
.adMgr_container .search_container > ul > li {
  font-size: 14px;
  color: #909399;
  margin-right: 15px;
  font-weight: bold;
}
.adMgr_container .search_container > ul > li:nth-of-type(1) .el-input {
  width: 150px;
}
.adMgr_container .main_container {
  margin-top: 15px;
}
.adMgr_container .main_container .el-row {
  margin-bottom: 15px;
  width: 570px;
}
.adMgr_container .main_container .el-form .el-form-item .el-form-item__label {
  font-size: 18px !important;
  font-weight: bold;
}
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 148px;
  height: 148px;
  line-height: 148px;
  text-align: center;
}
.avatar {
  width: 148px;
  height: 148px;
  display: block;
}
</style>
