<template>
  <div class="blacklistMgr_container">
    <section class="search_container">
      <ul style="display: flex;justify-content: start;">
        <li>
          UID：<el-input v-model="searchContent.searchKey"></el-input>
        </li>
        <li>
          <el-button-group>
            <el-button
              type="primary"
              @click="handleSearch"
            ><i class="el-icon-search"></i></el-button>
            <el-button
              type="primary"
              @click="resetSearchContent"
            ><i class="el-icon-refresh"></i></el-button>
          </el-button-group>
        </li>
      </ul>
    </section>
    <section class="main_container">
      <el-row>
        <el-button
          size="small"
          type="primary"
          @click="handleAddBlacklist"
        ><i class="el-icon-plus"></i> 添加黑名单</el-button>
      </el-row>
      <el-row>
        <el-table
          :data="blData"
          ref="blTable"
        >
          <el-table-column
            prop="gmId"
            label="UID"
            width="100"
          >

          </el-table-column>
          <el-table-column
            label="聊天"
            align="center"
          >
            <template slot-scope="scope">
              <i
                v-if="scope.row.isChat == 2"
                class="el-icon-error error"
              ></i>
              <i
                v-else
                class="el-icon-success success"
              ></i>
            </template>
          </el-table-column>
          <el-table-column
            label="添加好友"
            align="center"
          >
            <template slot-scope="scope">
              <i
                v-if="scope.row.isAddFriend == 2"
                class="el-icon-error error"
              ></i>
              <i
                v-else
                class="el-icon-success success"
              ></i>
            </template>
          </el-table-column>
          <el-table-column
            label="发布宣言"
            align="center"
          >
            <template slot-scope="scope">
              <i
                v-if="scope.row.isDeclare == 2"
                class="el-icon-error error"
              ></i>
              <i
                v-else
                class="el-icon-success success"
              ></i>
            </template>
          </el-table-column>
          <!-- <el-table-column
            label="评论"
            align="center"
          >
            <template slot-scope="scope">
              <i
                v-if="scope.row.isComment == 2"
                class="el-icon-error error"
              ></i>
              <i
                v-else
                class="el-icon-success success"
              ></i>
            </template>
          </el-table-column> -->
          <el-table-column
            label="操作"
            align="center"
          >
            <template slot-scope="scope">
              <el-button
                type="primary"
                size="mini"
                @click="handleEditBlacklist(scope.$index, scope.row)"
              >编辑</el-button>
              <el-button
                type="info"
                size="mini"
                @click="handleCancelBlacklist(scope.$index, scope.row)"
              >解除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-row>
      <el-row
        type="flex"
        justify="center"
      >
        <el-pagination
          @current-change="handleCurrentChange"
          :current-page.sync="searchContent.pageNum"
          :page-size="searchContent.pageSize"
          layout="total, prev, pager, next"
          :total="totalSize"
        >
        </el-pagination>
      </el-row>
    </section>

    <el-dialog
      :title="addBlacklistTitle"
      :visible="addBlacklistVisibleDialog"
      width="480px"
      @close="handleAddBlacklistClose"
    >
      <el-form label-width="70px">
        <el-form-item label="UID：">
          <el-input
            placeholder="请输入UID"
            :disabled="editUid"
            v-model="addBlacklistForm.uid"
          ></el-input>
        </el-form-item>
        <el-form-item label="操作：">
          <el-checkbox
            v-model="isChat"
            @change="handleIsChatChange"
          >禁止聊天</el-checkbox>
          <el-checkbox
            v-model="isAddFriend"
            @change="handleIsAddFriendChange"
          >禁止添加好友</el-checkbox>
          <el-checkbox
            v-model="isDeclare"
            @change="handleIsDeclareChange"
          >禁止发布宣言</el-checkbox>
          <!-- <el-checkbox
            v-model="isComment"
            @change="handleIsCommentChange"
          >禁止评论</el-checkbox> -->
        </el-form-item>
      </el-form>
      <span
        slot="footer"
        class="dialog-footer"
      >
        <el-button @click="addBlacklistVisibleDialog = false">取 消</el-button>
        <el-button
          type="primary"
          @click="createBlacklist"
        >确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import {
  getRequestData,
  addBlacklist,
  breakBlacklist,
  blacklist
} from "@/api/requestMethods";
import { formatTime } from "@/api/dateUtil";
import { clearSearchContent } from "@/api/searchUtil";
export default {
  data() {
    return {
      searchContent: {
        searchKey: "",
        pageNum: 1,
        pageSize: 10
      },

      searchBoolean: false,
      blData: [],
      totalSize: 0,

      addBlacklistTitle: "",
      addBlacklistVisibleDialog: false,
      editUid: false,
      isChat: false,
      isAddFriend: false,
      isDeclare: false,
      isComment: false,
      addBlacklistForm: {
        uid: "",
        isChat: 1,
        isAddFriend: 1,
        isDeclare: 1,
        isComment: 1
      },
    };
  },
  methods: {
    requestData() {
      let data = getRequestData();
      if (!this.searchBoolean) {
        this.searchContent = clearSearchContent(this.searchContent);
      }
      data.body = this.searchContent;
      blacklist(data)
        .then(res => {
          if (res.data.rtnCode == 1) {
            if (res.data.data) {
              this.totalSize = res.data.data.total;
              this.blData = res.data.data.records;
            }
          }
        })
        .catch(err => {
          this.$notify({
            title: "失败",
            message: "网络不好，请稍后再试！",
            type: "error",
            offset: 128
          });
        });
    },
    handleSearch() {
      this.searchContent.pageNum = 1;
      this.searchBoolean = true;
      this.requestData();
    },
    resetSearchContent() {
      this.searchContent.searchKey = "";
    },
    handleCurrentChange() {
      this.requestData();
    },

    handleAddBlacklist() {
      this.addBlacklistTitle = "添加黑名单：";
      this.addBlacklistVisibleDialog = true;
      this.editUid = false;
    },
    handleAddBlacklistClose() {
      this.addBlacklistVisibleDialog = false;
      this.addBlacklistForm.uid = "";
      this.addBlacklistForm.isChat = 1;
      this.addBlacklistForm.isAddFriend = 1;
      this.addBlacklistForm.isDeclare = 1;
      this.addBlacklistForm.isComment = 1;
      this.isChat = false;
      this.isAddFriend = false;
      this.isDeclare = false;
      this.isComment = false;
    },
    handleIsChatChange(val) {
      this.addBlacklistForm.isChat = this.getAuthB2I(val);
    },
    handleIsAddFriendChange(val) {
      this.addBlacklistForm.isAddFriend = this.getAuthB2I(val);
    },
    handleIsDeclareChange(val) {
      this.addBlacklistForm.isDeclare = this.getAuthB2I(val);
    },
    handleIsCommentChange(val) {
      this.addBlacklistForm.isComment = this.getAuthB2I(val);
    },
    createBlacklist() {
      if (this.addBlacklistForm.uid.length == 0) {
        this.$notify({
          title: "失败",
          message: "请输入UID！",
          type: "error",
          offset: 128
        });
        return false;
      } else if (!this.isChat && !this.isAddFriend && !this.isDeclare && !this.isComment) {
        this.$notify({
          title: "失败",
          message: "请选择禁止选项！",
          type: "error",
          offset: 128
        });
        return false;
      } else {
        let data = getRequestData();
        data.body = this.addBlacklistForm;
        addBlacklist(data)
          .then(res => {
            if (res.data.rtnCode == 1) {
              this.$notify({
                title: "成功",
                message: "操作成功！",
                type: "success",
                offset: 128
              });
              this.addBlacklistVisibleDialog = false;
              this.requestData();
            } else {
              this.$notify({
                title: "失败",
                message: res.data.errMsg,
                type: "error",
                offset: 128
              });
            }
          })
          .catch(err => {
            this.$notify({
              title: "失败",
              message: "网络错误，请稍后再试！",
              type: "error",
              offset: 128
            });
          });
      }
    },

    handleEditBlacklist(index, row) {
      this.addBlacklistTitle = "编辑黑名单：";
      this.addBlacklistVisibleDialog = true;
      this.editUid = true;
      this.addBlacklistForm.uid = row.gmId;
      this.addBlacklistForm.isChat = row.isChat;
      this.addBlacklistForm.isAddFriend = row.isAddFriend;
      this.addBlacklistForm.isDeclare = row.isDeclare;
      this.addBlacklistForm.isComment = row.isComment;

      this.isChat = this.getAuthI2B(row.isChat);
      this.isAddFriend = this.getAuthI2B(row.isAddFriend);
      this.isDeclare = this.getAuthI2B(row.isDeclare);
      this.isComment = this.getAuthI2B(row.isComment);
    },
    getAuthB2I(val) {
      if (val) {
        return 2;
      } else {
        return 1;
      }
    },
    getAuthI2B(val) {
      if (val == 1) {
        return false;
      } else if (val == 2) {
        return true;
      }
    },
    handleCancelBlacklist(index, row) {
      this.$confirm("请确认是否解除该条黑名单?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          let data = getRequestData();
          data.body = {
            uid: row.gmId
          };
          breakBlacklist(data)
            .then(res => {
              if (res.data.rtnCode == 1) {
                this.$notify({
                  title: "成功",
                  message: "解除成功！",
                  type: "success",
                  offset: 128
                });
                this.requestData();
              } else {
                this.$notify({
                  title: "失败",
                  message: "解除失败！",
                  type: "error",
                  offset: 128
                });
              }
            })
            .catch(err => {
              this.$notify({
                title: "失败",
                message: "网络错误，请稍后再试！",
                type: "error",
                offset: 128
              });
            });
        })
        .catch(() => {});
    }
  },
  mounted() {
    this.requestData();
    this.$store.commit("updateHeaderName", "黑名单");
    this.$store.commit("updateDefaultActive", "4");
  },
  filters: {
    formatTime(time) {
      let date = new Date(time);
      return formatTime(date, "yyyy-MM-dd hh:mm:ss");
    }
  }
};
</script>

<style scoped>
.blacklistMgr_container {
}
.blacklistMgr_container .search_container > ul > li {
  font-size: 14px;
  color: #909399;
  margin-right: 15px;
  font-weight: bold;
}
.blacklistMgr_container .search_container > ul > li:nth-of-type(1) .el-input {
  width: 150px;
}
.blacklistMgr_container .main_container {
  margin-top: 15px;
}
.blacklistMgr_container .main_container .el-row {
  margin-bottom: 15px;
}
</style>
