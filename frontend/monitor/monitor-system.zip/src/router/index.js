import Vue from 'vue'
import Router from 'vue-router'
import store from '../store'
import { getRequestData, getAdminPermission } from "@/api/requestMethods";

Vue.use(Router)

const MONITOR = {
  path: '/',
  name: "index",
  component: () => import('../pages/layout/Layout.vue'),
  children: [
    {
      path: '/',
      name: 'service-monitor',
      component: () => import('../pages/monitor/ServiceMonitor.vue')
    },
    {
      path: '/resourceMonitor',
      name: 'resource-monitor',
      component: () => import('../pages/monitor/ResourceMonitor.vue')
    }
  ]
}

const router = new Router({
  routes: [
    MONITOR,
    {
      name: '404',
      path: '/404',
      component: () => import('../components/NotFound.vue')
    },
    { path: '*', redirect: '/404' }
  ]
});

export default router;